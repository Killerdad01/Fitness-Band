package com.fitband.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.UUID

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var scanning = false

    companion object {
        private const val REQUEST_BLE = 9001
        private const val SCAN_MS = 12000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(NativeBridge(), "Android")

        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter
        scanner = bluetoothAdapter.bluetoothLeScanner
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun js(script: String) {
        runOnUiThread { webView.evaluateJavascript(script, null) }
    }

    private fun permissionsGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= 31) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                REQUEST_BLE
            )
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_BLE
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        if (!permissionsGranted()) {
            requestBlePermissions()
            return
        }
        if (!bluetoothAdapter.isEnabled) {
            toast("Turn Bluetooth on first")
            js("window.fitBandNative.onDisconnected()")
            return
        }

        stopScan()
        scanning = true
        js("window.fitBandNative.onScanStatus('Scanning for Mi Band 3…')")

        scanner?.startScan(scanCallback)

        window?.decorView?.postDelayed({
            if (scanning) {
                stopScan()
                js("window.fitBandNative.onScanStatus('Scan finished — no compatible band selected')")
            }
        }, SCAN_MS)
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        if (!scanning) return
        scanner?.stopScan(scanCallback)
        scanning = false
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = try { device.name ?: "" } catch (_: SecurityException) { "" }

            // Mi Band 3 commonly advertises with a Mi Band name. We also expose
            // unknown BLE devices to the UI so the user can diagnose discovery.
            if (name.contains("Mi Band", ignoreCase = true) ||
                name.contains("MI Band", ignoreCase = true) ||
                name.contains("Band 3", ignoreCase = true)) {
                stopScan()
                connect(device)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            js("window.fitBandNative.onScanStatus('BLE scan failed: $errorCode')")
        }
    }

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        gatt?.close()
        gatt = null
        val name = try { device.name ?: "Mi Band 3" } catch (_: SecurityException) { "Mi Band 3" }
        js("window.fitBandNative.onScanStatus('Connecting to ${JSONObject.quote(name)}')")
        gatt = device.connectGatt(this, false, gattCallback)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                js("window.fitBandNative.onConnected({name:'Mi Band 3', protocol:'BLE'})")
                if (ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                    gatt.discoverServices()
                }
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                js("window.fitBandNative.onDisconnected()")
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            js("window.fitBandNative.onScanStatus('BLE services discovered — Mi Band protocol adapter ready')")
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            // Generic notification hook. Mi Band 3 protocol parsing/authentication
            // must be implemented for real readings.
            val hex = characteristic.value?.joinToString("") { "%02x".format(it) } ?: ""
            js("window.fitBandNative.onBleNotification('${characteristic.uuid}', '$hex')")
        }
    }

    @SuppressLint("MissingPermission")
    private fun disconnect() {
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        js("window.fitBandNative.onDisconnected()")
    }

    private fun toast(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun scanAndConnect() {
            runOnUiThread { startScan() }
        }

        @JavascriptInterface
        fun disconnect() {
            runOnUiThread { disconnect() }
        }

        @JavascriptInterface
        fun requestSync() {
            js("window.fitBandNative.onScanStatus('Sync requested — Mi Band 3 protocol sync is not yet implemented')")
        }

        @JavascriptInterface
        fun startHeartRate() {
            js("window.fitBandNative.onScanStatus('Heart-rate command requested — protocol adapter is required')")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_BLE && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startScan()
        } else if (requestCode == REQUEST_BLE) {
            toast("Nearby devices permission is required")
        }
    }

    override fun onDestroy() {
        stopScan()
        gatt?.close()
        super.onDestroy()
    }
}
